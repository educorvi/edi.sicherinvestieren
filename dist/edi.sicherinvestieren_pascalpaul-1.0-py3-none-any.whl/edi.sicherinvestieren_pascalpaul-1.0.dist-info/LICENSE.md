MIT-Lizenz

Copyright (c) [2020] [Pascal-Daniel Paul]

Hiermit wird jeder Person, die eine Kopie erhält, kostenlos die Erlaubnis erteilt
dieser Software und der dazugehörigen Dokumentationsdateien (die "Software") zu behandeln
in der Software ohne Einschränkung, einschließlich ohne Einschränkung der Rechte
zu verwenden, zu kopieren, zu ändern, zusammenzuführen, zu veröffentlichen, zu verteilen, Unterlizenzen zu vergeben und / oder zu verkaufen
Kopien der Software und um Personen zuzulassen, für die die Software bestimmt ist
dafür eingerichtet, unter folgenden Bedingungen:

Der oben genannte Copyright-Hinweis und dieser Erlaubnishinweis sind in allen enthalten
Kopien oder wesentliche Teile der Software.

DIE SOFTWARE WIRD "WIE BESEHEN" OHNE JEGLICHE AUSDRÜCKLICHE ODER AUSDRÜCKLICHE GEWÄHRLEISTUNG ZUR VERFÜGUNG GESTELLT
STILLSCHWEIGEND, EINSCHLIESSLICH, ABER NICHT BESCHRÄNKT AUF DIE GARANTIEN DER MARKTGÄNGIGKEIT,
EIGNUNG FÜR EINEN BESTIMMTEN ZWECK UND NICHTVERLETZUNG. In keinem Fall wird das
AUTOREN ODER COPYRIGHT-INHABER HAFTEN FÜR ANSPRÜCHE, SCHÄDEN ODER ANDERE
HAFTUNG, OB BEI VERTRAGS-, TORT- ODER ANDERWEITIGEN MASSNAHMEN AUS,
AUS ODER IM ZUSAMMENHANG MIT DER SOFTWARE ODER DER NUTZUNG ODER ANDEREN HANDELN IN DER
SOFTWARE.
